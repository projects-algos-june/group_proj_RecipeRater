from django.apps import AppConfig


class RecipeDbConfig(AppConfig):
    name = 'recipe_db'
